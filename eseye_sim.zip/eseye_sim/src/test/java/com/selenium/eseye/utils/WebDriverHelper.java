package com.selenium.eseye.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverHelper {
	
	protected static Properties _userProperties = new Properties();
	

	static WebDriver driver = null;
	
	public WebDriverHelper() throws IOException{
		loadProperties();
	}

	private static Properties loadProperties() throws IOException {
		try{
			FileInputStream configStream = new FileInputStream("config.user.properties");
			_userProperties.load(configStream);
			return _userProperties;
		} catch (FileNotFoundException e){
			System.out.println("No config file Found");
		}
		return _userProperties;
		
	}
	
	public static String getStringProperty(String propertyname) throws FileNotFoundException{
		try{
			_userProperties = loadProperties();
		}catch(IOException e){
			e.printStackTrace();
		}
		String returnValue = _userProperties.getProperty(propertyname);
		return returnValue;
	}

	public static WebDriver createDriver() throws FileNotFoundException {
		if (driver == null) {
			System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+"\\lib\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.navigate().to(getStringProperty("url"));
			driver.manage().window().maximize();
		}
		return driver;

	}
	public static void getscreenshot() throws Exception {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\failure"+System.currentTimeMillis()+".png"));
	}

	public static void getscreenshot(String MethodName) throws Exception {
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\screenshot.png"));
		FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+MethodName+".png"));
		//FileUtils.copyFile(scrFile, new File("C:\\Users\\Hp\\Appium_Demo\\hybridfw\\screenshots\\"+System.currentTimeMillis()+".png"));
		/* try {
			 	String filePath="C:\\Users\\Hp\\Appium_Demo\\hybridfw\\screenshots\\";
				FileUtils.copyFile(scrFile, new File(filePath+methodName+".png"));
				System.out.println("***Placed screen shot in "+filePath+" ***");
			} catch (IOException e) {
				e.printStackTrace();
			}
 }*/
	}
	
	public static void Wait(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	

}
