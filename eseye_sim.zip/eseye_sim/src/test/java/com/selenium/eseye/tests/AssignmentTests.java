package com.selenium.eseye.tests;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.selenium.eseye.pages.HomePage;
import com.selenium.eseye.pages.LoginPage;
import com.selenium.eseye.utils.BaseTest;
	
public class AssignmentTests extends BaseTest {
	BaseTest test;
	LoginPage loginPage;
	HomePage homePage;
	WebDriver driver;
	private static final Logger log = LogManager.getLogger(AssignmentTests.class);
	
	@DataProvider(name = "Locations")
	public static Object[][] Locations() {
		return new Object[][] { { "Bangalore", " Bangalore" }, { "Chennai"}, { "New Delhi" }};
	}
	SoftAssert assertion = new SoftAssert();
	
	/**
	 * Verify user is able to login on providing the valid username and password
	 * @throws Exception
	 */
	@Test(priority=03)
	public void verify_successful_login() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.logout();
	}
	
	/**
	 * Verify user is not allowed to login on providing invalid username and password
	 */
	@Test(priority=02)
	public void verify_invalid_login() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passwrd12");
		loginPage.clickOnSignin();
		loginPage.verifyLoginPageHeader("Account login");
	}

	
	@Test(priority=01)
	public void verify_warning_message_invalid_login() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passwrd12");
		loginPage.clickOnSignin();
		loginPage.verifyWarningMessage("The details you supplied were incorrect. Please enter your details below and log in.");
	}
	
	@Test(priority=04)
	public void verify_search_sim_iccid() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.selectSearchOption("ICCID");
		homePage.enterSearchText("088547");
		homePage.clickOnSearchButton();
		homePage.verifyICCID("8999922009220088547");
		homePage.logout();
	}
	
	@Test(priority=05)
	public void verify_search_sim_msisdn() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.selectSearchOption("MSISDN");
		homePage.enterSearchText("28852");
		homePage.clickOnSearchButton();
		homePage.verifyMSSID("44745256128852");
		homePage.logout();
	}
	
	@Test(priority=06)
	public void verify_search_sim_ipaddress() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.selectSearchOption("IP");
		homePage.enterSearchText("130.204");
		homePage.clickOnSearchButton();
		homePage.verifyIP("10.212.130.204");
		homePage.logout();
	}
	
	@Test(priority=7)
	public void verify_action_summary() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionSummary("SIM summary");
		homePage.logout();
	}
	
	@Test(priority=8)
	public void verify_action_simsettings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionSimSettings("SIM Settings");
		homePage.logout();
	}
	
	@Test(priority=9)
	public void verify_action_network_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionNetworkSettings("SIM Network Settings");
		homePage.logout();
	}
	
	@Test(priority=10)
	public void verify_action_contract_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionContractSettings("SIM Contract Settings");
		homePage.logout();
	}
	
	@Test(priority=11)
	public void verify_action_billing_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionBilling("Unauthorized Access");
		homePage.logout();
	}
	
	@Test(priority=12)
	public void verify_action_message_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionMessaging("SIM Messaging Activity");
		homePage.logout();
	}
	
	@Test(priority=13)
	public void verify_action_radius_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionRadius("SIM Radius Activity");
		homePage.logout();
	}
	
	@Test(priority=14)
	public void verify_action_netflow_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionNetFlow("SIM NetFlow Activity");
		homePage.logout();
	}
	
	@Test(priority=15)
	public void verify_action_control_panel_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionControlPanel("SIM Control Panel");
		homePage.logout();
	}
	
	@Test(priority=16)
	public void verify_action_audit_settings() throws Exception{
		loginPage.enterUsername("tester");
		loginPage.enterPassword("Passw0rd12");
		homePage = loginPage.clickOnSignin();
		homePage.verifyHomePageHeader("SIMs");
		homePage.verifyActionAudit("SIM Audit Log");
		homePage.logout();
	}
	
	@BeforeClass
	public void setup() {
		loginPage = new LoginPage(getDriver());
	}

}
