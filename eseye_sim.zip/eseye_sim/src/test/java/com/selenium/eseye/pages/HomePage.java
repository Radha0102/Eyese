package com.selenium.eseye.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.selenium.eseye.utils.WebDriverHelper;

public class HomePage extends BasePage {

	WebDriver driver;

	@FindBy(xpath = "//*[@class='bolder']/h3")
	private WebElement _txtHeader;

	@FindBy(xpath = "//*[@class='active']")
	private WebElement _isSearchForActive;

	@FindBy(xpath = "//*[@class='btn-group']/button")
	private WebElement _dropDownSearchFor;

	@FindBy(xpath = "//label[contains(text(),'ICCID')]")
	private WebElement _optionICCID;

	@FindBy(xpath = "//label[contains(text(),'MSISDN')]")
	private WebElement _optionMSISDN;

	@FindBy(xpath = "//label[contains(text(),'SIMID')]")
	private WebElement _optionSIMID;

	@FindBy(xpath = "//label[contains(text(),'IP')]")
	private WebElement _optionIP;

	@FindBy(name = "matchString")
	private WebElement _txtSearchString;

	@FindBy(className = "btnVeryBig")
	private WebElement _btnSearch;

	@FindBy(id = "iccid")
	private WebElement _columnICCID;
	
	@FindBy(xpath="//*[@id='simTbody']/tr[1]/td[4]")
	private WebElement _columnMSSID;
	
	@FindBy(xpath="//*[@id='simTbody']/tr/td[5]")
	private WebElement _columnIP;
	
	@FindBy(xpath="//*[contains(text(),'TESTER TES...')]")
	private WebElement _userAccount;
	
	@FindBy(xpath="//*[contains(text(),'Logout')]")
	private WebElement _menuLogout;
	
	@FindBy(xpath="(//*[@title='summary'])[1]")
	private WebElement _btnSimSummary;
	
	@FindBy(xpath="//*[@id='subtitle']/span/h3")
	private WebElement _simSummaryHeader;
	
	@FindBy(xpath="(//*[@title='sim-settings'])[1]")
	private WebElement _btnSimSettings;
	
	@FindBy(xpath="(//*[@title='network-settings'])[1]")
	private WebElement _btnNetworkSettings;
	
	@FindBy(xpath="(//*[@title='contract-settings'])[1]")
	private WebElement _btnContractSettings;
	
	@FindBy(xpath="(//*[@title='billing'])[1]")
	private WebElement _btnBillingSettings;
	
	@FindBy(xpath="(//*[@title='messaging'])[1]")
	private WebElement _btnMessaging;
	
	@FindBy(xpath="(//*[@title='radius'])[1]")
	private WebElement _btnRadius;
	
	@FindBy(xpath="(//*[@title='netflow'])[1]")
	private WebElement _btnNetflow;
	
	@FindBy(xpath="//*[@id='8999922009220088539/controls/S']")
	private WebElement _btnControl;
	
	@FindBy(xpath="(//*[@title='Audit'])[1]")
	private WebElement _btnAudit;
	
	@FindBy(xpath = "//*[@class='md-content']/img")
	private WebElement _closePopup;

	public HomePage(WebDriver driver) {
		super(driver);
	}

	public void implicitWaits() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void verifyHomePageHeader(String header) {
		WebDriverHelper.Wait(_txtHeader);
		String value = _txtHeader.getText();
		Assert.assertEquals(value, header);
	}

	public void selectSearchOption(String value) {
		WebDriverHelper.Wait(_dropDownSearchFor);
		_dropDownSearchFor.click();
		int count = getDriver().findElements(By.xpath("//*[@class='active']")).size();
		for (int i = 0; i <= count; i++) {
			try {
				getDriver().findElement(By.xpath("//*[@class='active']//label/input")).click();
			} catch (Exception ex) {

			}
		}
		if (value.equals("ICCID")) {
			_optionICCID.click();
		} else if (value.equals("MSISDN")) {
			_optionMSISDN.click();
		} else if (value.equals("SIMID")) {
			_optionSIMID.click();
		} else if (value.equals("IP")) {
			_optionIP.click();
		}

	}

	public boolean isSearch() {
		try {
			_isSearchForActive.isDisplayed();
			return true;
		} catch (Exception ex) {
			return false;
		}
	}

	public void enterSearchText(String value) {
		_txtSearchString.sendKeys(value);
	}

	public void clickOnSearchButton() {
		_btnSearch.click();
	}

	public void verifyICCID(String value) {
		WebDriverHelper.Wait(_columnICCID);
		Assert.assertEquals(_columnICCID.getText(), value);
	}

	public void verifyMSSID(String value) {
		WebDriverHelper.Wait(_columnMSSID);
		Assert.assertEquals(_columnMSSID.getText(), value);
	}

	public void verifyIP(String value) {
		WebDriverHelper.Wait(_columnIP);
		Assert.assertEquals(_columnIP.getText(), value);		
	}
	
	public void logout() {
		WebDriverHelper.Wait(_userAccount);
		Actions actions = new Actions(getDriver());
		actions.moveToElement(_userAccount).build().perform();
		_menuLogout.click();
	}

	public void verifyActionSummary(String value) {
		WebDriverHelper.Wait(_btnSimSummary);
		_btnSimSummary.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionSimSettings(String value) {
		WebDriverHelper.Wait(_btnSimSettings);
		_btnSimSettings.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionNetworkSettings(String value) {
		WebDriverHelper.Wait(_btnNetworkSettings);
		_btnNetworkSettings.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionContractSettings(String value) {
		WebDriverHelper.Wait(_btnContractSettings);
		_btnContractSettings.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionBilling(String value) {
		WebDriverHelper.Wait(_btnBillingSettings);
		_btnBillingSettings.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionMessaging(String value) {
		WebDriverHelper.Wait(_btnMessaging);
		_btnMessaging.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionRadius(String value) {
		WebDriverHelper.Wait(_btnRadius);
		_btnRadius.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionNetFlow(String value) {
		WebDriverHelper.Wait(_btnNetflow);
		_btnNetflow.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionControlPanel(String value) {
		WebDriverHelper.Wait(_btnControl);
		_btnControl.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
	
	public void verifyActionAudit(String value) {
		WebDriverHelper.Wait(_btnAudit);
		_btnAudit.click();
		getDriver().switchTo().frame("iframe");
		WebDriverHelper.Wait(_simSummaryHeader);
		Assert.assertTrue(_simSummaryHeader.getText().contains(value));	
		getDriver().switchTo().defaultContent();
		WebDriverHelper.Wait(_closePopup);
		_closePopup.click();
	}
}
