package com.selenium.eseye.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import com.selenium.eseye.utils.WebDriverHelper;

public class LoginPage extends BasePage {

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(xpath = "//*[@class='bolder']/h3")
	private WebElement _txtHeader;
	
	@FindBy(id="errorMessage")
	private WebElement _txtErrorMessage;

	@FindBy(id = "username")
	private WebElement _txtUsername;

	@FindBy(id = "password")
	private WebElement _txtPassword;

	@FindBy(id = "login")
	private WebElement _btnSignin;

	public void enterUsername(String username) {
		_txtUsername.sendKeys(username);
	}

	public void enterPassword(String password) {
		_txtPassword.sendKeys(password);
	}

	public HomePage clickOnSignin() {
		_btnSignin.click();
		return new HomePage(getDriver());
	}

	public void verifyLoginPageHeader(String header) {
		WebDriverHelper.Wait(_txtHeader);
		String value = _txtHeader.getText();
		Assert.assertEquals(value, header);		
	}
	
	public void verifyWarningMessage(String header) {
		WebDriverHelper.Wait(_txtHeader);
		String value = _txtErrorMessage.getText();
		Assert.assertEquals(value, header);		
	}
}
